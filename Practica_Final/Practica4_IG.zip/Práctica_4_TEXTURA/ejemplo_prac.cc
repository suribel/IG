#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <string>
#include <vector>

#include "CImg.h"
using namespace cimg_library;

void Init();
void OnDraw();

void prepara_textura(void);

void dibuja(void);

void libera_textura(void);

GLuint textura_id;


void Init (int argc, char **argv){

    

}

void OnDraw(void){
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();


    ///cosas

    gluLookAt(
        5.0, 10, 20, //eye position
        0.0, 0, 0.0, //target
        0.0, 1.0, 0.0); //define positive Y axis
        
    glTranslatef(-2,0,0);

    //put your code

    dibuja();

    glutSwapBuffers();


}


int main(int argc, char **argv){

    glutInit(&argc, argv);

    glutInitWindowSize(800,600);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutCreateWindow("hello");

    ///cosas coment
    //GL_LIGHT0
    glEnable(GL_DEPTH_TEST);
    glMatrixMode(GL_PROJECTION);

    gluPerspective(40.0, 800/600.0f, 0.1, 150);
    
    prepara_textura();








    glutDisplayFunc(OnDraw);

    glutMainLoop();

    libera_textura();

    return 0;

}



void prepara_textura(void){

    std::vector<unsigned char> data;
    
    CImg<unsigned char> logo;
    logo.load("./skybox.jpg");

    for (long y = 0; y < logo.height(); y++)
    {
        for (long x = 0; x < logo.width(); x++)
        {
            unsigned char *r = logo.data(x, y, 0, 0);
            unsigned char *g = logo.data(x, y, 0, 1);
            unsigned char *b = logo.data(x, y, 0, 2);
            data.push_back(*r);
            data.push_back(*g);
            data.push_back(*b);
        }        
    }
    //crear textura
    glGenTextures(1, &textura_id);
    //enlazar textura
    glBindTexture(GL_TEXTURE_2D, textura_id);

    glActiveTexture(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, logo.width(), logo.height(), 0, GL_RGB, GL_UNSIGNED_BYTE, &data[0]);

}



void dibuja (void){

    GLfloat vertices[] = {
    0.0, 0.0, 5.0,   5.0, 0.0, 5.0,   5.0, 5.0, 5.0,  0.0, 5.0, 5.0,
  0.0, 5.0, 0.0,  5.0, 5.0, 0.0,  5.0, 0.0, 0.0, 0.0, 0.0, 0.0,
  5.0, 0.0, 5.0,   5.0, 0.0, 0.0,  5.0, 5.0, 0.0,  5.0, 5.0, 5.0,
  0.0, 0.0, 0.0,  0.0, 0.0, 5.0,  0.0, 5.0, 5.0, 0.0, 5.0, 0.0,
  5.0, 5.0, 5.0,  0.0, 5.0, 5.0,  0.0, 5.0, 0.0,  5.0, 5.0, 0.0,
  5.0, 0.0, 5.0,  0.0, 0.0, 5.0,  0.0, 0.0, 0.0,  5.0, 5.0, 0.0
  };
            
GLfloat texVertices[] = {
    0.0,0.0, 1.0,0.0, 1.0,1.0, 0.0,1.0,
    0.0,0.0, 1.0,0.0, 1.0,1.0, 0.0,1.0,
    0.0,0.0, 1.0,0.0, 1.0,1.0, 0.0,1.0,
    0.0,0.0, 1.0,0.0, 1.0,1.0, 0.0,1.0,
    0.0,0.0, 1.0,0.0, 1.0,1.0, 0.0,1.0
                               
                               };

    glEnable(GL_TEXTURE_2D);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY_EXT);

    //Esto estaba en codigo manual ???glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textura_id);

    glVertexPointer(3, GL_FLOAT, 0, vertices);
    glTexCoordPointer(2, GL_FLOAT, 0, texVertices);

    glDrawArrays(GL_QUADS, 0, 24);

    glDisableClientState(GL_VERTEX_ARRAY);

    glBindTexture(GL_TEXTURE_2D, 0);
    glDisable(GL_TEXTURE_2D);



}


void libera_textura(void){
    glDeleteTextures(1, &textura_id);
}
